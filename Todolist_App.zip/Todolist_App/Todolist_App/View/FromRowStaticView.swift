//
//  FromRowStaticView.swift
//  Todolist_App
//
//  Created by Muhammad Azzura Al Karazi on 22/02/21.
//

import SwiftUI

struct FromRowStaticView: View {
    
    var icon : String
    var firstText : String
    var secondText : String
    
    var body: some View {
        HStack{
            ZStack{
                RoundedRectangle(cornerRadius: 0, style: .continuous)
                    .fill(Color.gray)
                Image(systemName: icon)
                    .foregroundColor(.white)
            }//Zstack
            .frame(width: 36, height: 36, alignment: .center)
            Text(firstText)
                .foregroundColor(.black)
            Spacer()
            Text(secondText)
        }
    }
}

struct FromRowStaticView_Previews: PreviewProvider {
    static var previews: some View {
        FromRowStaticView(icon: "gear", firstText: "Application", secondText: "Todo")
            .previewLayout(.fixed(width: 375, height: 60))
            .padding()
        
    }
}
